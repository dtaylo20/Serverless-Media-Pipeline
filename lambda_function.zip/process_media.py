import boto3
import json

# Initialize AWS Services
rekognition = boto3.client('rekognition')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('MediaMetadata') # Matches your Terraform name

def lambda_handler(event, context):
    # 1. Get the bucket name and file name from the S3 event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    print(f"Processing file {key} from bucket {bucket}")

    # 2. Call AWS Rekognition to detect labels (objects) in the image
    response = rekognition.detect_labels(
        Image={'S3Object': {'Bucket': bucket, 'Name': key}},
        MaxLabels=5
    )

    # 3. Extract the label names
    labels = [label['Name'] for label in response['Labels']]
    print(f"Detected labels: {labels}")

    # 4. Store the results in DynamoDB
    table.put_item(
        Item={
            'FileName': key,
            'Labels': labels,
            'Bucket': bucket
        }
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Metadata stored successfully!')
    }